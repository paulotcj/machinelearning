# Workshop - Neural Networks
## Objective

The objective is having folks walk away from the workshop with a better
understanding of the fundemental building blocks of neural networks.

### Requirements

 - Code Editor
 - Browser
